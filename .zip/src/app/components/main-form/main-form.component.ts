import { Component } from '@angular/core';
import {
  FormGroup,
  FormControl,
  ReactiveFormsModule,
  FormArray,
} from '@angular/forms';
import { CommonModule } from '@angular/common';

import { ShippingFormComponent } from '../shipping-form/shipping-form.component';
import { ButtonModule } from 'primeng/button';
import { StepperModule } from 'primeng/stepper';
import { SecondFormComponent } from '../second-form/second-form.component';
import { RatesFormComponent } from '../rates-form/rates-form.component';
import { InfoFormComponent } from '../info-form/info-form.component';

@Component({
  selector: 'app-main-form',
  standalone: true,
  imports: [
    CommonModule,
    ShippingFormComponent,
    ReactiveFormsModule,
    ButtonModule,
    StepperModule,
    SecondFormComponent,
    RatesFormComponent,
    InfoFormComponent,
  ],
  templateUrl: './main-form.component.html',
  styleUrls: ['./main-form.component.css'],
})
export class MainFormComponent {
  mainForm: FormGroup;
  selectedCard: any = null; // Store the selected card here

  constructor() {
    this.mainForm = new FormGroup({
      shippingFrom: new FormGroup({
        country: new FormControl(''),
        city: new FormControl(''),
        area: new FormControl(''),
        floor: new FormControl(''),
        address: new FormControl(''),
        contactName: new FormControl(''),
        phoneNumber: new FormControl(''),
        addressType: new FormControl('commercial'),
      }),
      shippingTo: new FormGroup({
        country: new FormControl(''),
        city: new FormControl(''),
        area: new FormControl(''),
        floor: new FormControl(''),
        address: new FormControl(''),
        contactName: new FormControl(''),
        phoneNumber: new FormControl(''),
        addressType: new FormControl('commercial'),
      }),
      secondForm: new FormGroup({
        length: new FormControl(''),
        width: new FormControl(''),
        height: new FormControl(''),
        weight: new FormControl(''),
        description: new FormControl(''),
        quantity: new FormControl(''),
        items: new FormArray([]),
      }),
    });
  }

  get shippingFromForm(): FormGroup {
    return this.mainForm.get('shippingFrom') as FormGroup;
  }

  get shippingToForm(): FormGroup {
    return this.mainForm.get('shippingTo') as FormGroup;
  }

  get secondForm(): FormGroup {
    return this.mainForm.get('secondForm') as FormGroup;
  }

  swapForms() {
    const fromData = this.shippingFromForm.value;
    this.mainForm.patchValue({
      shippingFrom: this.shippingToForm.value,
      shippingTo: fromData,
    });
  }

  submitForm() {
    console.log('Shipping From Form Data:', this.shippingFromForm.value);
    console.log('Shipping To Form Data:', this.shippingToForm.value);
    console.log('Selected Card:', this.selectedCard); // Log the selected card
  }

  onCardSelected(card: any) {
    this.selectedCard = card; // Store the selected card from RatesFormComponent
    console.log('Card selected in main form:', this.selectedCard);
  }
  currentStep = 1; // Change dynamically
}
