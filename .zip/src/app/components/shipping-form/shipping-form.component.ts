import { Component, Input } from '@angular/core';
import { FormControl, FormGroup, ReactiveFormsModule } from '@angular/forms';
import { InputFieldComponent } from '../input-field/input-field.component';
import { InputSelectorComponent } from '../input-selector/input-selector.component';
import { RadioGroupComponent } from '../radio-group/radio-group.component';

@Component({
  selector: 'app-shipping-form',
  imports: [
    InputFieldComponent,
    InputSelectorComponent,
    RadioGroupComponent,
    ReactiveFormsModule,
  ],
  templateUrl: './shipping-form.component.html',
  styleUrl: './shipping-form.component.css',
})
export class ShippingFormComponent {
  @Input() title!: string;
  @Input() form!: FormGroup;

  cities = [
    { name: 'New York', code: 'NY' },
    { name: 'Rome', code: 'RM' },
    { name: 'London', code: 'LDN' },
    { name: 'Istanbul', code: 'IST' },
    { name: 'Paris', code: 'PRS' },
  ];

  selectedAddress: string = 'residential';
}
